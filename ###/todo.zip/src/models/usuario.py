from src import db, login_manager
from flask_login import UserMixin
from datetime import datetime

@login_manager.user_loader
def load_user(user_id):
    return Usuario.query.get(int(user_id))

class Usuario(db.Model, UserMixin):
    __tablename__ = "usuarios"
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    senha = db.Column(db.String(60), nullable=False)
    setor = db.Column(db.String(50), nullable=True)  # Contábil, Fiscal, Folha de Pagamento
    tipo_usuario = db.Column(db.String(20), nullable=False, default="normal")  # normal, gestor
    data_cadastro = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    # Relacionamento com Tarefas (usuário designado para a tarefa)
    tarefas_designadas = db.relationship("Tarefa", foreign_keys="Tarefa.designado_para_id", backref="designado_para", lazy=True)

    def __repr__(self):
        return f"Usuario(\'{self.nome}\', \'{self.email}\', \'{self.tipo_usuario}\')"

    def get_tipo_usuario_display(self):
        return self.tipo_usuario.capitalize()

# Outros modelos podem ser adicionados aqui ou em arquivos separados dentro de src/models

class Empresa(db.Model):
    __tablename__ = "empresas"
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False, unique=True)
    cnpj = db.Column(db.String(18), nullable=False, unique=True) # Formato XX.XXX.XXX/XXXX-XX
    regime_tributario = db.Column(db.String(50), nullable=False) # Simples Nacional, Lucro Presumido, Lucro Real
    data_cadastro = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    tarefas = db.relationship("Tarefa", backref="empresa", lazy=True)
    documentos = db.relationship("Documento", backref="empresa", lazy=True)

    def __repr__(self):
        return f"Empresa(\'{self.nome}\', \'{self.cnpj}\')"

class Tarefa(db.Model):
    __tablename__ = "tarefas"
    id = db.Column(db.Integer, primary_key=True)
    descricao = db.Column(db.String(200), nullable=False)
    setor = db.Column(db.String(50), nullable=False) # Contábil, Fiscal, Folha de Pagamento
    prazo = db.Column(db.DateTime, nullable=False)
    status = db.Column(db.String(20), nullable=False, default="pendente") # pendente, em andamento, concluída, atrasada
    prioridade = db.Column(db.String(10), nullable=False, default="media") # alta, média, baixa
    data_criacao = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    data_conclusao = db.Column(db.DateTime, nullable=True)

    empresa_id = db.Column(db.Integer, db.ForeignKey("empresas.id"), nullable=False)
    designado_para_id = db.Column(db.Integer, db.ForeignKey("usuarios.id"), nullable=True)

    def __repr__(self):
        return f"Tarefa(\'{self.descricao}\', \'{self.status}\')"

class TipoDocumento(db.Model):
    __tablename__ = "tipos_documentos"
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False, unique=True) # ex.: Nota Fiscal, Extrato Bancário
    frequencia = db.Column(db.String(20), nullable=False) # diária, semanal, mensal

    documentos = db.relationship("Documento", backref="tipo_documento", lazy=True)

    def __repr__(self):
        return f"TipoDocumento(\'{self.nome}\')"

class Documento(db.Model):
    __tablename__ = "documentos"
    id = db.Column(db.Integer, primary_key=True)
    prazo = db.Column(db.DateTime, nullable=False)
    status = db.Column(db.String(20), nullable=False, default="pendente") # pendente, recebido, atrasado
    data_recebimento = db.Column(db.DateTime, nullable=True)

    empresa_id = db.Column(db.Integer, db.ForeignKey("empresas.id"), nullable=False)
    tipo_documento_id = db.Column(db.Integer, db.ForeignKey("tipos_documentos.id"), nullable=False)

    def __repr__(self):
        return f"Documento(\'{self.tipo_documento.nome}\', \'{self.empresa.nome}\', \'{self.status}\')"

