from src import db
db.create_all()
exit()
