from flask import Blueprint, render_template
from flask_login import login_required, current_user
from src.models.usuario import Tarefa # Supondo que o modelo Tarefa esteja em usuario.py ou models.py

main_bp = Blueprint("main", __name__)

@main_bp.route("/")
@main_bp.route("/index")
@login_required
def index():
    # A página inicial pode ser o dashboard ou uma página de boas-vindas
    # Por enquanto, vamos redirecionar para um futuro dashboard ou mostrar tarefas
    tarefas = []
    if current_user.is_authenticated:
        if current_user.tipo_usuario == "gestor":
            # Gestor vê tarefas do seu setor (exemplo simplificado)
            # No futuro, filtrar por current_user.setor
            tarefas = Tarefa.query.order_by(Tarefa.prazo.asc()).all()
        else:
            # Usuário normal vê apenas suas tarefas
            tarefas = Tarefa.query.filter_by(designado_para_id=current_user.id).order_by(Tarefa.prazo.asc()).all()
    return render_template("index.html", title="Página Inicial", tarefas=tarefas)

@main_bp.route("/dashboard")
@login_required
def dashboard():
    tarefas = []
    # Lógica similar à index para buscar tarefas baseadas no tipo de usuário
    if current_user.tipo_usuario == "gestor":
        # Aqui você pode adicionar filtros mais complexos, por setor, status, etc.
        tarefas = Tarefa.query.order_by(Tarefa.data_criacao.desc()).all()
    else:
        tarefas = Tarefa.query.filter_by(designado_para_id=current_user.id).order_by(Tarefa.data_criacao.desc()).all()
    
    # Para a visualização do progresso, você pode calcular estatísticas aqui
    # Ex: total_tarefas, concluidas, pendentes, em_andamento, atrasadas
    stats = {
        "total": len(tarefas),
        "concluidas": len([t for t in tarefas if t.status == "concluída"]),
        "pendentes": len([t for t in tarefas if t.status == "pendente"]),
        "em_andamento": len([t for t in tarefas if t.status == "em andamento"]),
        "atrasadas": len([t for t in tarefas if t.status == "atrasada"])
    }
    return render_template("dashboard.html", title="Painel de Tarefas", tarefas=tarefas, stats=stats)

