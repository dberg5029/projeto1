## Documentação do Projeto: Sistema de Gerenciamento de Tarefas

### 1. Visão Geral

Este documento descreve o sistema de gerenciamento de tarefas desenvolvido, detalhando sua arquitetura, funcionalidades e instruções de uso. O sistema foi construído utilizando Flask para o backend, SQLAlchemy para interação com o banco de dados, e HTML/CSS/JavaScript para o frontend.

### 2. Arquitetura do Sistema

O sistema segue uma arquitetura Model-View-Controller (MVC), separando as responsabilidades em diferentes componentes:

*   **Modelos (Models):** Define a estrutura dos dados, como usuários, tarefas e documentos. Utiliza SQLAlchemy para mapear esses modelos para tabelas em um banco de dados relacional.
*   **Rotas (Routes/Controllers):** Lida com as requisições HTTP, processa os dados de entrada e interage com os modelos para realizar operações no banco de dados. Utiliza Flask para definir as rotas e manipular as requisições.
*   **Templates (Views):** Apresenta os dados ao usuário através de HTML. Utiliza o sistema de templates Jinja2, integrado ao Flask, para renderizar as páginas dinamicamente.
*   **Formulários (Forms):** Utiliza Flask-WTF para criar e validar formulários web, facilitando a interação do usuário com o sistema.
*   **Autenticação e Autorização:** Flask-Login é usado para gerenciar sessões de usuário e proteger rotas que exigem login.
*   **Segurança:** Bcrypt é utilizado para hashing de senhas, garantindo que as senhas não sejam armazenadas em texto plano.

### 3. Funcionalidades Implementadas

*   **Registro de Usuários:** Novos usuários podem se registrar no sistema fornecendo um nome, email e senha. A senha é armazenada de forma segura usando hashing.
*   **Login de Usuários:** Usuários registrados podem fazer login usando seu email e senha.
*   **Painel de Controle (Dashboard):** Após o login, os usuários são direcionados para um painel onde podem visualizar suas tarefas e documentos.
*   **Gerenciamento de Tarefas:**
    *   **Criação:** Usuários podem criar novas tarefas, especificando título, descrição, prazo e prioridade.
    *   **Visualização:** Tarefas são exibidas em uma lista, possivelmente com opções de filtragem e ordenação.
    *   **Atualização:** Usuários podem editar tarefas existentes.
    *   **Exclusão:** Usuários podem excluir tarefas.
*   **Gerenciamento de Documentos:**
    *   **Upload:** Usuários podem fazer upload de documentos relacionados às tarefas ou projetos.
    *   **Download:** Documentos enviados podem ser baixados pelos usuários autorizados.
    *   **Visualização (Opcional):** Dependendo do tipo de arquivo, pode haver uma pré-visualização ou visualização direta no navegador.
*   **Controle de Acesso:** O sistema diferencia usuários normais de gestores, com gestores tendo permissões adicionais (ex: criar tarefas para outros, excluir tarefas de outros).

### 4. Estrutura do Projeto (Diretórios e Arquivos)

```
projeto_software_quantico/
├── app.py                 # Arquivo principal da aplicação Flask
├── config.py              # Configurações da aplicação (ex: chave secreta, URI do banco)
├── requirements.txt       # Lista de dependências do projeto
├── static/                # Arquivos estáticos (CSS, JavaScript, imagens)
│   ├── css/
│   └── js/
├── templates/             # Templates HTML (usando Jinja2)
│   ├── base.html          # Template base com estrutura comum
│   ├── login.html         # Página de login
│   ├── register.html      # Página de registro
│   ├── dashboard.html     # Painel do usuário
│   └── ...                # Outros templates HTML
├── src/
│   ├── __init__.py
│   ├── models.py          # Definições dos modelos de dados (SQLAlchemy)
│   ├── forms.py           # Definições dos formulários (Flask-WTF)
│   ├── routes.py          # Definições das rotas e lógica de visualização
│   └── utils.py           # Funções utilitárias (opcional)
└── instance/
    └── site.db            # Arquivo do banco de dados SQLite (pode variar)
```

### 5. Configuração e Execução

**Pré-requisitos:**

*   Python 3.x instalado.
*   `pip` (gerenciador de pacotes Python) instalado.

**Passos para Execução:**

1.  **Clonar o Repositório (se aplicável):**
    ```bash
    git clone <URL_DO_REPOSITORIO>
    cd projeto_software_quantico
    ```

2.  **Criar e Ativar um Ambiente Virtual:**
    ```bash
    python3 -m venv venv
    source venv/bin/activate  # No Linux/macOS
    # ou
    venv\Scripts\activate    # No Windows (prompt de comando)
    # ou
    . venv/Scripts/activate   # No Windows (Git Bash ou similar)
    ```

3.  **Instalar as Dependências:**
    ```bash
    pip install -r requirements.txt
    ```
    Isso instalará Flask, Flask-SQLAlchemy, Flask-Login, Flask-WTF, bcrypt, PyMySQL (se estiver usando MySQL), e outras dependências necessárias.

4.  **Configurar o Banco de Dados:**
    *   **SQLite (Padrão):** Nenhuma configuração adicional é necessária. O banco de dados (`site.db`) será criado automaticamente no diretório `instance`.
    *   **MySQL (Opcional):**
        1.  Certifique-se de ter um servidor MySQL em execução.
        2.  Crie um banco de dados (ex: `projeto_quantico_db`).
        3.  Configure as variáveis de ambiente para a conexão com o banco de dados (geralmente em um arquivo `.env` ou diretamente no `config.py`):
            ```
            DATABASE_URL="mysql+pymysql://usuario:senha@host/nome_do_banco"
            ```

5.  **Executar as Migrações do Banco de Dados (se aplicável, especialmente para SQLAlchemy com Flask-Migrate):**
    ```bash
    flask db init  # Se for a primeira vez
    flask db migrate -m "Initial migration."
    flask db upgrade
    ```

6.  **Executar a Aplicação:**
    ```bash
    python3 app.py
    ```
    Por padrão, a aplicação estará acessível em `http://127.0.0.1:5000`.

### 6. Uso da Aplicação

Após iniciar a aplicação, acesse o endereço `http://127.0.0.1:5000` (ou o endereço configurado) em seu navegador.

*   **Registro:** Se for um novo usuário, clique no link de registro e preencha o formulário com seu nome, email e senha.
*   **Login:** Se já tiver uma conta, utilize o formulário de login com seu email e senha.
*   **Painel de Controle:** Após o login, você será redirecionado para o painel de controle, onde poderá visualizar suas tarefas e documentos.
*   **Gerenciamento de Tarefas:** Crie, edite ou exclua tarefas conforme necessário.
*   **Gerenciamento de Documentos:** Faça upload ou download de documentos relacionados às suas tarefas ou projetos.

### 7. Considerações Adicionais

*   **Segurança:** Lembre-se de que a chave secreta (`SECRET_KEY`) e as credenciais do banco de dados devem ser mantidas em segredo e nunca devem ser versionadas diretamente no código em um ambiente de produção. Utilize variáveis de ambiente ou arquivos de configuração seguros.
*   **Desenvolvimento vs. Produção:** O servidor de desenvolvimento do Flask não é recomendado para ambientes de produção. Para produção, utilize um servidor WSGI como Gunicorn ou uWSGI, juntamente com um servidor web como Nginx ou Apache.
*   **Backup de Dados:** Implemente uma estratégia de backup regular para o banco de dados, especialmente em ambientes de produção.

Este guia deve fornecer uma boa base para entender e utilizar o sistema de gerenciamento de tarefas. Se precisar de mais detalhes sobre alguma funcionalidade específica, consulte a documentação do código ou entre em contato com a equipe de desenvolvimento.
