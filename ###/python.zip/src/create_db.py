# src/create_db.py
from src import create_app, db
from src.models.usuario import Usuario, Tarefa

def init_db():
    app = create_app()
    with app.app_context():
        db.drop_all()
        db.create_all()
        print("✅ Banco de dados criado com sucesso!")
        print(f"📁 Local do banco: {app.config['SQLALCHEMY_DATABASE_URI']}")

if __name__ == '__main__':
    init_db()