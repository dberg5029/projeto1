# src/models/usuario.py
from src import db
from flask_login import UserMixin
from datetime import datetime

class Usuario(db.Model, UserMixin):
    __tablename__ = 'usuarios'
    __table_args__ = {'extend_existing': True}
    
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    senha = db.Column(db.String(255), nullable=False)
    tipo_usuario = db.Column(db.String(20), nullable=False, default='comum')
    data_criacao = db.Column(db.DateTime, default=datetime.utcnow)
    setor = db.Column(db.String(50))
    
    # Relacionamentos
    tarefas_criadas = db.relationship('Tarefa', foreign_keys='Tarefa.criador_id', backref='criador', lazy=True)
    tarefas_designadas = db.relationship('Tarefa', foreign_keys='Tarefa.designado_para_id', backref='designado', lazy=True)

    def __repr__(self):
        return f"Usuario('{self.nome}', '{self.email}', '{self.tipo_usuario}')"

class Tarefa(db.Model):
    __tablename__ = 'tarefas'
    __table_args__ = {'extend_existing': True}
    
    id = db.Column(db.Integer, primary_key=True)
    titulo = db.Column(db.String(100), nullable=False)
    descricao = db.Column(db.Text)
    status = db.Column(db.String(20), default='pendente')
    prioridade = db.Column(db.String(10), default='media')
    data_criacao = db.Column(db.DateTime, default=datetime.utcnow)
    prazo = db.Column(db.DateTime)
    data_conclusao = db.Column(db.DateTime)
    
    # Chaves estrangeiras
    criador_id = db.Column(db.Integer, db.ForeignKey('usuarios.id'), nullable=False)
    designado_para_id = db.Column(db.Integer, db.ForeignKey('usuarios.id'), nullable=False)

    def __repr__(self):
        return f"Tarefa('{self.titulo}', '{self.status}', '{self.prazo}')"