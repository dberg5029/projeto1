# src/routes/usuarios.py
from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from src import db
from src.models.usuario import Usuario
from src.forms import LoginForm, RegisterForm

usuarios_bp = Blueprint('usuarios', __name__)

@usuarios_bp.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    
    form = RegisterForm()
    if form.validate_on_submit():
        hashed_password = generate_password_hash(form.senha.data)
        user = Usuario(
            nome=form.nome.data,
            email=form.email.data,
            senha=hashed_password,
            tipo_usuario=form.tipo_usuario.data
        )
        db.session.add(user)
        db.session.commit()
        flash('Conta criada com sucesso!', 'success')
        return redirect(url_for('usuarios.login'))
    
    return render_template('register.html', title='Register', form=form)

@usuarios_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    
    form = LoginForm()
    if form.validate_on_submit():
        user = Usuario.query.filter_by(email=form.email.data).first()
        if user and check_password_hash(user.senha, form.senha.data):
            login_user(user, remember=form.lembrar.data)
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('main.index'))
        else:
            flash('Login falhou. Verifique email e senha', 'danger')
    
    return render_template('login.html', title='Login', form=form)

@usuarios_bp.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('main.index'))