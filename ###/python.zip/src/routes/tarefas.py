from flask import Blueprint

tarefas_bp = Blueprint("tarefas", __name__)

@tarefas_bp.route("/tarefas")
def index():
    return "Página de Tarefas"

